import '../models/training_course_model.dart';

class TrainingCourseService {
  static final List<TrainingCourse> courses = [
    TrainingCourse(
      title: 'Newborn care basics',
      expertName: 'Pediatric Care Channel',
      youtubeUrl: 'https://www.youtube.com/watch?v=2vqhTU16Dr4',
      thumbnailUrl: 'https://img.youtube.com/vi/2vqhTU16Dr4/0.jpg',
    ),
    TrainingCourse(
      title: 'Building a gentle sleep routine',
      expertName: 'Child Sleep Consultant',
      youtubeUrl: 'https://www.youtube.com/watch?v=nm1TxQj9IsQ',
      thumbnailUrl: 'https://img.youtube.com/vi/nm1TxQj9IsQ/0.jpg',
    ),
    TrainingCourse(
      title: 'First solid foods and baby nutrition',
      expertName: 'Parenting Tips',
      youtubeUrl: 'https://www.youtube.com/watch?v=RzB0xA3gLwM',
      thumbnailUrl: 'https://img.youtube.com/vi/RzB0xA3gLwM/0.jpg',
    ),
    TrainingCourse(
      title: 'Learning through play',
      expertName: 'Child Psychologist',
      youtubeUrl: 'https://www.youtube.com/watch?v=3nXSpYH3q5s',
      thumbnailUrl: 'https://img.youtube.com/vi/3nXSpYH3q5s/0.jpg',
    ),
    TrainingCourse(
      title: 'Helpful tips for parents',
      expertName: 'Parenting School',
      youtubeUrl: 'https://www.youtube.com/watch?v=RVA2N6tX2cg',
      thumbnailUrl: 'https://img.youtube.com/vi/RVA2N6tX2cg/0.jpg',
    ),
  ];
}
