import 'dart:convert';

import 'package:flutter/services.dart';

import '../models/advice_model.dart';

class AdviceService {
  const AdviceService();

  static const String _assetPath = 'assets/data/motherhood_advice.json';

  Future<List<Advice>> loadAdvice() async {
    final raw = await rootBundle.loadString(_assetPath);
    final decoded = jsonDecode(raw);
    if (decoded is! List) {
      throw const AdviceServiceException('Advice catalog must be a list.');
    }

    return decoded
        .whereType<Map<String, dynamic>>()
        .map(Advice.fromJson)
        .where(
          (advice) => advice.title.isNotEmpty && advice.category.isNotEmpty,
        )
        .toList(growable: false);
  }

  Future<List<Advice>> search({String query = '', String? category}) async {
    final catalog = await loadAdvice();
    return catalog
        .where((advice) {
          final categoryMatches =
              category == null ||
              category == 'All' ||
              advice.category == category;
          return categoryMatches && advice.matches(query);
        })
        .toList(growable: false);
  }

  Future<List<String>> categories() async {
    final catalog = await loadAdvice();
    return catalog.map((advice) => advice.category).toSet().toList()..sort();
  }
}

class AdviceServiceException implements Exception {
  const AdviceServiceException(this.message);

  final String message;

  @override
  String toString() => message;
}
