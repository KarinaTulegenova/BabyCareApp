import '../core/constants/app_assets.dart';
import '../core/constants/app_routes.dart';
import '../models/category_item_model.dart';
import '../models/doctor_model.dart';
import '../models/service_model.dart';

class MotherhoodDataService {
  const MotherhoodDataService._();

  static const List<CategoryItemModel> categories = [
    CategoryItemModel(
      title: 'Pediatricians',
      image: AppAssets.doctorAigerim,
      route: AppRoutes.veterinary,
    ),
    CategoryItemModel(
      title: 'Daily Care',
      image: AppAssets.categoryHygiene,
      route: AppRoutes.grooming,
    ),
    CategoryItemModel(
      title: 'Baby Shop',
      image: AppAssets.categoryNutrition,
      route: AppRoutes.shop,
    ),
    CategoryItemModel(
      title: 'Videos',
      image: AppAssets.categoryToys,
      route: AppRoutes.training,
    ),
  ];

  static const List<ServiceModel> specialistServices = [
    ServiceModel(
      title: 'Pediatric Checkup',
      subtitle: '12 000 KZT',
      image: AppAssets.doctorAigerim,
      price: 12000,
    ),
    ServiceModel(
      title: 'Sleep Consultation',
      subtitle: '18 000 KZT',
      image: AppAssets.doctorAruzhan,
      price: 18000,
    ),
    ServiceModel(
      title: 'Child Psychologist',
      subtitle: '20 000 KZT',
      image: AppAssets.doctorAlikhan,
      price: 20000,
    ),
    ServiceModel(
      title: 'Child Nutrition',
      subtitle: '16 000 KZT',
      image: AppAssets.categoryNutrition,
      price: 16000,
    ),
  ];

  static const List<DoctorModel> specialists = [
    DoctorModel(
      name: 'Aigerim',
      specialty: 'Pediatrician',
      image: AppAssets.doctorAigerim,
      rating: 4.9,
      distance: '1 km',
      price: '20 000 KZT',
      experience: '12 years',
    ),
    DoctorModel(
      name: 'Aruzhan',
      specialty: 'Child Sleep Specialist',
      image: AppAssets.doctorAruzhan,
      rating: 4.8,
      distance: '1.5 km',
      price: '18 000 KZT',
      experience: '9 years',
    ),
    DoctorModel(
      name: 'Alikhan',
      specialty: 'Child Psychologist',
      image: AppAssets.doctorAlikhan,
      rating: 4.9,
      distance: '2.5 km',
      price: '22 000 KZT',
      experience: '8 years',
    ),
  ];

  static const List<ServiceModel> careServices = [
    ServiceModel(
      title: 'Baby Bathing',
      subtitle: 'Daily hygiene',
      details:
          'Keep baths short, warm, and calm. Prepare towels, clean clothes, and skin-care products before you start.',
      image: AppAssets.categoryHygiene,
      price: 0,
    ),
    ServiceModel(
      title: 'Skin Care',
      subtitle: 'Irritation prevention',
      details:
          'Use fragrance-free products, dry skin gently, and watch for persistent redness or rash.',
      image: AppAssets.categoryHygiene,
      price: 0,
    ),
    ServiceModel(
      title: 'Nail Care',
      subtitle: 'Safe trimming',
      details:
          'Trim nails when your baby is calm or asleep. Use rounded baby scissors and good lighting.',
      image: AppAssets.categoryHygiene,
      price: 0,
    ),
    ServiceModel(
      title: 'Ear Care',
      subtitle: 'Gentle hygiene',
      details:
          'Clean only the outer ear with a soft cloth. Do not insert cotton swabs into the ear canal.',
      image: AppAssets.categoryHygiene,
      price: 0,
    ),
    ServiceModel(
      title: 'Home First Aid',
      subtitle: 'Basic essentials',
      details:
          'Keep a thermometer, saline drops, sterile wipes, and pediatrician contacts in one easy-to-find place.',
      image: AppAssets.categoryHealth,
      price: 0,
    ),
    ServiceModel(
      title: 'Walks',
      subtitle: 'Clothes and routine',
      details:
          'Dress in comfortable layers, avoid overheating, and plan walks around feeding and sleep windows.',
      image: AppAssets.categoryClothes,
      price: 0,
    ),
  ];

  static const List<ServiceModel> shopItems = [
    ServiceModel(title: 'Nutrition', image: AppAssets.categoryNutrition),
    ServiceModel(title: 'Health', image: AppAssets.categoryHealth),
    ServiceModel(title: 'Toys', image: AppAssets.categoryToys),
    ServiceModel(title: 'Hygiene', image: AppAssets.categoryHygiene),
    ServiceModel(title: 'Accessories', image: AppAssets.categoryAccessories),
    ServiceModel(title: 'Clothes', image: AppAssets.categoryClothes),
  ];

  static const List<ServiceModel> courses = [
    ServiceModel(
      title: 'Newborn Care',
      subtitle: 'Practical basics',
      image: AppAssets.course1,
    ),
    ServiceModel(
      title: 'Baby Sleep Routine',
      subtitle: 'Gentle rituals',
      image: AppAssets.course2,
    ),
    ServiceModel(
      title: 'First Solid Foods',
      subtitle: 'Safe start',
      image: AppAssets.course3,
    ),
    ServiceModel(
      title: 'Learning Through Play',
      subtitle: 'Everyday ideas',
      image: AppAssets.course4,
    ),
  ];
}
