import 'package:flutter/material.dart';

import '../../core/constants/app_sizes.dart';
import '../../core/constants/app_routes.dart';
import '../../core/theme/app_colors.dart';
import '../../models/service_model.dart';
import '../../services/activity_log_service.dart';
import '../../services/cart_service.dart';
import '../../services/motherhood_data_service.dart';
import '../../widgets/custom_card.dart';

class ShopCategoryScreen extends StatelessWidget {
  const ShopCategoryScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final category = _categoryFromArgs(context);
    final products = _productsFor(category);

    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          tooltip: 'Back',
          onPressed: () => Navigator.pop(context),
          icon: const Icon(
            Icons.chevron_left_rounded,
            color: AppColors.primary,
          ),
        ),
        title: Text(category.title),
      ),
      body: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: AppSizes.screenMaxWidth),
          child: ListView.builder(
            padding: const EdgeInsets.all(AppSpacing.xl),
            itemCount: products.length,
            itemBuilder: (context, index) {
              final product = products[index];
              final icon = _iconFor(category.title, index);
              final color = _iconColor(index);
              return Padding(
                padding: const EdgeInsets.only(bottom: AppSpacing.lg),
                child: CustomCard(
                  onTap: () => _addToCart(context, product),
                  child: Row(
                    children: [
                      Container(
                        width: 72,
                        height: 72,
                        decoration: BoxDecoration(
                          color: color.withValues(alpha: .14),
                          borderRadius: BorderRadius.circular(AppRadius.lg),
                        ),
                        child: Icon(icon, color: color, size: 34),
                      ),
                      const SizedBox(width: AppSpacing.lg),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              product.title,
                              style: Theme.of(context).textTheme.titleMedium
                                  ?.copyWith(fontWeight: FontWeight.w700),
                            ),
                            const SizedBox(height: AppSpacing.xs),
                            Text(
                              product.subtitle ?? 'Baby Care pick',
                              style: Theme.of(context).textTheme.bodySmall
                                  ?.copyWith(color: AppColors.muted),
                            ),
                            const SizedBox(height: AppSpacing.xs),
                            Text(
                              _formatPrice(product.price),
                              style: Theme.of(context).textTheme.bodyMedium
                                  ?.copyWith(
                                    color: AppColors.primary,
                                    fontWeight: FontWeight.w700,
                                  ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        ),
      ),
    );
  }

  ServiceModel _categoryFromArgs(BuildContext context) {
    final args = ModalRoute.of(context)?.settings.arguments;
    if (args is ServiceModel) {
      return args;
    }
    return MotherhoodDataService.shopItems.first;
  }

  List<ServiceModel> _productsFor(ServiceModel category) {
    return _shopProductCatalog[category.title] ??
        _shopProductCatalog['Nutrition']!;
  }

  IconData _iconFor(String category, int index) {
    final icons = _shopProductIcons[category];
    if (icons == null || icons.isEmpty) {
      return _categoryIcons[category] ?? Icons.child_care_rounded;
    }
    return icons[index % icons.length];
  }

  Color _iconColor(int index) {
    const colors = [
      AppColors.primary,
      AppColors.success,
      AppColors.warning,
      Color(0xFF7C7BEF),
      Color(0xFFE85D8E),
      Color(0xFF35A7A0),
    ];
    return colors[index % colors.length];
  }

  void _addToCart(BuildContext context, ServiceModel product) {
    CartService.add(product);
    ActivityLogService.add('Cart ${product.title}');
    final messenger = ScaffoldMessenger.of(context);
    messenger.hideCurrentSnackBar();
    messenger.showSnackBar(
      SnackBar(
        content: Text('${product.title} added to cart'),
        behavior: SnackBarBehavior.floating,
        duration: const Duration(seconds: 1),
        action: SnackBarAction(
          label: 'Cart',
          onPressed: () {
            messenger.hideCurrentSnackBar();
            Navigator.pushNamed(context, AppRoutes.cart);
          },
        ),
      ),
    );
  }
}

String _formatPrice(int value) {
  final raw = value.toString();
  final buffer = StringBuffer();
  for (var i = 0; i < raw.length; i++) {
    final remaining = raw.length - i;
    buffer.write(raw[i]);
    if (remaining > 1 && remaining % 3 == 1) {
      buffer.write(' ');
    }
  }
  return '${buffer.toString()} KZT';
}

const Map<String, List<ServiceModel>> _shopProductCatalog = {
  'Nutrition': [
    ServiceModel(
      title: 'Baby formula',
      subtitle: 'Essential nutrition recommended by a specialist',
      image: '',
      price: 7800,
    ),
    ServiceModel(
      title: 'Sugar-free cereal',
      subtitle: 'Gentle texture for first solids',
      image: '',
      price: 2900,
    ),
    ServiceModel(
      title: 'Vegetable puree',
      subtitle: 'Simple ingredients for first tastes',
      image: '',
      price: 1200,
    ),
    ServiceModel(
      title: 'Sippy cup',
      subtitle: 'Convenient cup for walks',
      image: '',
      price: 3600,
    ),
    ServiceModel(
      title: 'Feeding spoons',
      subtitle: 'Soft edges for first meals',
      image: '',
      price: 1800,
    ),
    ServiceModel(
      title: 'Food containers',
      subtitle: 'Portion storage for baby food',
      image: '',
      price: 3200,
    ),
  ],
  'Health': [
    ServiceModel(
      title: 'Baby thermometer',
      subtitle: 'Quick temperature checks',
      image: '',
      price: 6500,
    ),
    ServiceModel(
      title: 'Nasal aspirator',
      subtitle: 'Helpful for nasal congestion',
      image: '',
      price: 4300,
    ),
    ServiceModel(
      title: 'Humidifier',
      subtitle: 'Comfortable nursery air',
      image: '',
      price: 28000,
    ),
    ServiceModel(
      title: 'Baby first aid kit',
      subtitle: 'Organizer for essentials',
      image: '',
      price: 9800,
    ),
    ServiceModel(
      title: 'Diaper cream',
      subtitle: 'Skin protection from irritation',
      image: '',
      price: 2600,
    ),
    ServiceModel(
      title: 'Sunscreen',
      subtitle: 'Age-appropriate outdoor care',
      image: '',
      price: 5200,
    ),
  ],
  'Toys': [
    ServiceModel(
      title: 'Soft sensory cube',
      subtitle: 'Textures for sensory development',
      image: '',
      price: 3900,
    ),
    ServiceModel(
      title: 'Rattle',
      subtitle: 'Light toy for first games',
      image: '',
      price: 2200,
    ),
    ServiceModel(
      title: 'Teether',
      subtitle: 'Safe support for teething',
      image: '',
      price: 2400,
    ),
    ServiceModel(
      title: 'Bath book',
      subtitle: 'Play and first words at bath time',
      image: '',
      price: 3100,
    ),
    ServiceModel(
      title: 'Stacking toy',
      subtitle: 'Colors, size, and coordination',
      image: '',
      price: 4500,
    ),
    ServiceModel(
      title: 'Play mat',
      subtitle: 'Supervised floor play',
      image: '',
      price: 18500,
    ),
  ],
  'Hygiene': [
    ServiceModel(
      title: 'Diapers',
      subtitle: 'Soft fit for daily care',
      image: '',
      price: 7800,
    ),
    ServiceModel(
      title: 'Wet wipes',
      subtitle: 'Fragrance-free care',
      image: '',
      price: 1700,
    ),
    ServiceModel(
      title: 'Baby shampoo',
      subtitle: 'Gentle tear-free bathing',
      image: '',
      price: 2600,
    ),
    ServiceModel(
      title: 'Nail scissors',
      subtitle: 'Rounded edges for safety',
      image: '',
      price: 1900,
    ),
    ServiceModel(
      title: 'Changing pads',
      subtitle: 'For home, travel, and checkups',
      image: '',
      price: 4300,
    ),
    ServiceModel(
      title: 'Baby bathtub',
      subtitle: 'Stable shape for bathing',
      image: '',
      price: 16500,
    ),
  ],
  'Accessories': [
    ServiceModel(
      title: 'Organizer bag',
      subtitle: 'Everything needed for a walk',
      image: '',
      price: 3500,
    ),
    ServiceModel(
      title: 'Baby sling',
      subtitle: 'Closeness with free hands',
      image: '',
      price: 1500,
    ),
    ServiceModel(
      title: 'Thermal bag',
      subtitle: 'For bottles and snacks',
      image: '',
      price: 2800,
    ),
    ServiceModel(
      title: 'Night light',
      subtitle: 'Soft light for night care',
      image: '',
      price: 6400,
    ),
    ServiceModel(
      title: 'Bottle brush',
      subtitle: 'Convenient daily hygiene',
      image: '',
      price: 3900,
    ),
    ServiceModel(
      title: 'Car seat',
      subtitle: 'Safety on the road',
      image: '',
      price: 14500,
    ),
  ],
  'Clothes': [
    ServiceModel(
      title: 'Cotton bodysuit',
      subtitle: 'Soft everyday layer',
      image: '',
      price: 8900,
    ),
    ServiceModel(
      title: 'Warm jumpsuit',
      subtitle: 'For cool walks',
      image: '',
      price: 7600,
    ),
    ServiceModel(
      title: 'Baby hat',
      subtitle: 'Comfort after bathing and outdoors',
      image: '',
      price: 1800,
    ),
    ServiceModel(
      title: 'Pajamas',
      subtitle: 'Comfortable sleepwear',
      image: '',
      price: 8200,
    ),
    ServiceModel(
      title: 'Socks',
      subtitle: 'Soft fit without pressure',
      image: '',
      price: 5400,
    ),
    ServiceModel(
      title: 'Bibs',
      subtitle: 'For feeding and teething',
      image: '',
      price: 2600,
    ),
  ],
};

const Map<String, IconData> _categoryIcons = {
  'Nutrition': Icons.restaurant_rounded,
  'Health': Icons.health_and_safety_rounded,
  'Toys': Icons.toys_rounded,
  'Hygiene': Icons.bathtub_rounded,
  'Accessories': Icons.local_mall_rounded,
  'Clothes': Icons.checkroom_rounded,
};

const Map<String, List<IconData>> _shopProductIcons = {
  'Nutrition': [
    Icons.restaurant_rounded,
    Icons.dinner_dining_rounded,
    Icons.cookie_rounded,
    Icons.cleaning_services_rounded,
    Icons.local_drink_rounded,
    Icons.rice_bowl_rounded,
  ],
  'Health': [
    Icons.health_and_safety_rounded,
    Icons.spa_rounded,
    Icons.healing_rounded,
    Icons.clean_hands_rounded,
    Icons.medical_services_rounded,
    Icons.shield_rounded,
  ],
  'Toys': [
    Icons.toys_rounded,
    Icons.sports_baseball_rounded,
    Icons.extension_rounded,
    Icons.sports_handball_rounded,
    Icons.smart_toy_rounded,
    Icons.album_rounded,
  ],
  'Hygiene': [
    Icons.baby_changing_station_rounded,
    Icons.wash_rounded,
    Icons.bathtub_rounded,
    Icons.back_hand_rounded,
    Icons.dry_cleaning_rounded,
    Icons.water_rounded,
  ],
  'Accessories': [
    Icons.style_rounded,
    Icons.sell_rounded,
    Icons.rice_bowl_rounded,
    Icons.linear_scale_rounded,
    Icons.brush_rounded,
    Icons.local_mall_rounded,
  ],
  'Clothes': [
    Icons.checkroom_rounded,
    Icons.dry_cleaning_rounded,
    Icons.celebration_rounded,
    Icons.layers_rounded,
    Icons.directions_walk_rounded,
    Icons.auto_awesome_rounded,
  ],
};
