import 'package:flutter/material.dart';

import '../../core/constants/app_assets.dart';
import '../../core/constants/app_routes.dart';
import '../../core/constants/app_sizes.dart';
import '../../core/theme/app_colors.dart';
import '../../core/utils/navigation_utils.dart';
import '../../models/service_model.dart';
import '../../services/activity_log_service.dart';
import '../../services/cart_service.dart';
import '../../services/motherhood_data_service.dart';
import '../../widgets/custom_card.dart';
import '../../widgets/feature_card.dart';
import '../../widgets/search_box.dart';
import '../../widgets/section_header.dart';

class GroomingScreen extends StatelessWidget {
  const GroomingScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          tooltip: 'Back',
          onPressed: () => NavigationUtils.backOrDashboard(context),
          icon: const Icon(
            Icons.chevron_left_rounded,
            color: AppColors.primary,
          ),
        ),
        title: const Text('Daily Care'),
      ),
      body: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: AppSizes.screenMaxWidth),
          child: ListView(
            padding: const EdgeInsets.all(AppSpacing.xl),
            children: [
              FeatureCard(
                title: 'Gentle care every day',
                subtitle: 'Hygiene, bathing, skin, and walks',
                image: AppAssets.dailySupport,
              ),
              const SizedBox(height: AppSpacing.lg),
              const SearchBox(hint: 'Search daily care tips'),
              const SizedBox(height: AppSpacing.lg),
              SectionHeader(
                title: 'Care topics',
                onActionTap: () => Navigator.pushNamed(
                  context,
                  AppRoutes.serviceList,
                  arguments: MotherhoodDataService.careServices,
                ),
              ),
              const SizedBox(height: AppSpacing.lg),
              ListView.separated(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                itemCount: MotherhoodDataService.careServices.length,
                separatorBuilder: (_, _) =>
                    const SizedBox(height: AppSpacing.lg),
                itemBuilder: (context, index) {
                  final service = MotherhoodDataService.careServices[index];
                  return _CareDetailCard(
                    service: service,
                    onTap: () => _addServiceToCart(context, service),
                  );
                },
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _addServiceToCart(BuildContext context, ServiceModel service) {
    CartService.add(service);
    ActivityLogService.add('Cart ${service.title}');
    final messenger = ScaffoldMessenger.of(context);
    messenger.hideCurrentSnackBar();
    messenger.showSnackBar(
      SnackBar(
        content: Text('${service.title} added to cart'),
        behavior: SnackBarBehavior.floating,
        duration: const Duration(seconds: 1),
        action: SnackBarAction(
          label: 'Cart',
          onPressed: () {
            messenger.hideCurrentSnackBar();
            Navigator.pushNamed(context, AppRoutes.cart);
          },
        ),
      ),
    );
  }
}

class _CareDetailCard extends StatelessWidget {
  const _CareDetailCard({required this.service, required this.onTap});

  final ServiceModel service;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return CustomCard(
      padding: const EdgeInsets.all(AppSpacing.lg),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(AppRadius.lg),
            child: Image.asset(
              service.image,
              width: 84,
              height: 84,
              fit: BoxFit.cover,
              cacheWidth: 220,
            ),
          ),
          const SizedBox(width: AppSpacing.lg),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  service.title,
                  style: Theme.of(
                    context,
                  ).textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w700),
                ),
                if (service.subtitle != null) ...[
                  const SizedBox(height: AppSpacing.xs),
                  Text(
                    service.subtitle!,
                    style: Theme.of(context).textTheme.bodySmall?.copyWith(
                      color: AppColors.primary,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ],
                if (service.details != null) ...[
                  const SizedBox(height: AppSpacing.sm),
                  Text(
                    service.details!,
                    maxLines: 3,
                    overflow: TextOverflow.ellipsis,
                    style: Theme.of(context).textTheme.bodySmall?.copyWith(
                      color: AppColors.muted,
                      height: 1.35,
                    ),
                  ),
                ],
                const SizedBox(height: AppSpacing.md),
                Align(
                  alignment: Alignment.centerLeft,
                  child: FilledButton.icon(
                    onPressed: onTap,
                    icon: const Icon(Icons.add_shopping_cart_rounded, size: 18),
                    label: const Text('Add to cart'),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
