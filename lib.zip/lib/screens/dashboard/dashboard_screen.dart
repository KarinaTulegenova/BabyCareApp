import 'package:flutter/material.dart';
import '../../core/constants/app_assets.dart';
import '../../core/constants/app_routes.dart';
import '../../core/constants/app_sizes.dart';
import '../../core/theme/app_colors.dart';
import '../../models/service_model.dart';
import '../../services/activity_log_service.dart';
import '../../services/motherhood_data_service.dart';
import '../../widgets/app_bottom_nav_bar.dart';
import '../../widgets/category_item.dart';
import '../../widgets/custom_card.dart';
import '../../widgets/feature_card.dart';
import '../../widgets/search_box.dart';
import '../../widgets/section_header.dart';

class DashboardScreen extends StatelessWidget {
  const DashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        bottom: false,
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(
              maxWidth: AppSizes.screenMaxWidth,
            ),
            child: ListView(
              padding: const EdgeInsets.fromLTRB(
                AppSpacing.xl,
                AppSpacing.lg,
                AppSpacing.xl,
                AppSizes.bottomBarHeight + AppSpacing.xl,
              ),
              children: [
                Row(
                  children: [
                    Material(
                      color: AppColors.primarySoft,
                      shape: const CircleBorder(),
                      child: InkWell(
                        customBorder: const CircleBorder(),
                        onTap: () {
                          ActivityLogService.add('Opened profile');
                          Navigator.pushNamed(context, AppRoutes.profile);
                        },
                        child: const SizedBox(
                          width: AppSizes.avatar,
                          height: AppSizes.avatar,
                          child: Icon(
                            Icons.person_outline_rounded,
                            color: AppColors.primary,
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: AppSpacing.sm),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Hello, Karina',
                            style: Theme.of(context).textTheme.titleSmall
                                ?.copyWith(fontWeight: FontWeight.w700),
                          ),
                          const SizedBox(height: AppSpacing.xs),
                          Text(
                            'A calm day for gentle care',
                            style: Theme.of(context).textTheme.bodyMedium
                                ?.copyWith(color: AppColors.muted),
                          ),
                        ],
                      ),
                    ),
                    IconButton(
                      tooltip: 'Activity log',
                      onPressed: () =>
                          Navigator.pushNamed(context, AppRoutes.activityLog),
                      icon: const Icon(Icons.notifications_none_rounded),
                    ),
                  ],
                ),
                const SizedBox(height: AppSpacing.xl),
                const SearchBox(hint: 'Search sleep, nutrition, or care tips'),
                const SizedBox(height: AppSpacing.xl),
                FeatureCard(
                  title: 'Daily support for parents',
                  subtitle: 'Care, development, and child health tips',
                  image: AppAssets.dailySupport,
                  onTap: () =>
                      Navigator.pushNamed(context, AppRoutes.searchResults),
                ),
                const SizedBox(height: AppSpacing.xl),
                SectionHeader(
                  title: 'Child health',
                  onActionTap: () =>
                      Navigator.pushNamed(context, AppRoutes.veterinary),
                ),
                const SizedBox(height: AppSpacing.lg),
                GridView.builder(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  itemCount: 4,
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2,
                    mainAxisSpacing: AppSpacing.md,
                    crossAxisSpacing: AppSpacing.md,
                    childAspectRatio: 2.6,
                  ),
                  itemBuilder: (context, index) {
                    final item =
                        MotherhoodDataService.specialistServices[index];
                    return _DashboardShopCard(
                      item: item,
                      onTap: () =>
                          Navigator.pushNamed(context, AppRoutes.veterinary),
                    );
                  },
                ),
                const SizedBox(height: AppSpacing.xl),
                SectionHeader(
                  title: 'Sections',
                  onActionTap: () =>
                      Navigator.pushNamed(context, AppRoutes.categoryList),
                ),
                const SizedBox(height: AppSpacing.lg),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: MotherhoodDataService.categories
                      .map(
                        (item) => CategoryItem(
                          title: item.title,
                          image: item.image,
                          icon: _categoryIcon(item.title),
                          onTap: () => Navigator.pushNamed(context, item.route),
                        ),
                      )
                      .toList(),
                ),
                const SizedBox(height: AppSpacing.xl),
                Text(
                  'Helpful videos',
                  style: Theme.of(
                    context,
                  ).textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w600),
                ),
                const SizedBox(height: AppSpacing.lg),
                FeatureCard(
                  title: 'Newborn care\nbasics',
                  subtitle: 'Videos, sleep, nutrition, and first months',
                  image: AppAssets.newbornCareBasics,
                  buttonLabel: 'Watch',
                  onTap: () => Navigator.pushNamed(context, AppRoutes.training),
                  onPressed: () =>
                      Navigator.pushNamed(context, AppRoutes.training),
                ),
                const SizedBox(height: AppSpacing.xl),
                Text(
                  'Daily recommendation',
                  style: Theme.of(
                    context,
                  ).textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w600),
                ),
                const SizedBox(height: AppSpacing.lg),
                FeatureCard(
                  title: 'Check home safety',
                  subtitle:
                      'Small items, medicine, and household chemicals should stay out of reach',
                  image: AppAssets.checkHomeSafely,
                  buttonLabel: 'Open tips',
                  onTap: () =>
                      Navigator.pushNamed(context, AppRoutes.searchResults),
                  onPressed: () =>
                      Navigator.pushNamed(context, AppRoutes.searchResults),
                ),
              ],
            ),
          ),
        ),
      ),
      bottomNavigationBar: const AppBottomNavBar(currentIndex: 0),
    );
  }

  IconData _categoryIcon(String title) {
    return switch (title) {
      'Pediatricians' => Icons.medical_services_outlined,
      'Daily Care' => Icons.bathtub_outlined,
      'Baby Shop' => Icons.shopping_bag_outlined,
      'Videos' => Icons.play_circle_outline_rounded,
      _ => Icons.child_care_rounded,
    };
  }
}

class _DashboardShopCard extends StatelessWidget {
  const _DashboardShopCard({required this.item, required this.onTap});

  final ServiceModel item;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return CustomCard(
      onTap: onTap,
      padding: const EdgeInsets.all(AppSpacing.sm),
      child: Row(
        children: [
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              color: AppColors.primarySoft,
              borderRadius: BorderRadius.circular(AppRadius.md),
            ),
            child: Icon(_iconFor(item.title), color: AppColors.primary),
          ),
          const SizedBox(width: AppSpacing.sm),
          Expanded(
            child: Text(
              item.title,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: Theme.of(
                context,
              ).textTheme.bodyMedium?.copyWith(fontWeight: FontWeight.w700),
            ),
          ),
        ],
      ),
    );
  }

  IconData _iconFor(String title) {
    return switch (title) {
      'Pediatric Checkup' => Icons.medical_services_outlined,
      'Sleep Consultation' => Icons.nightlight_outlined,
      'Child Psychologist' => Icons.psychology_alt_outlined,
      'Child Nutrition' => Icons.restaurant_outlined,
      _ => Icons.child_care_rounded,
    };
  }
}
