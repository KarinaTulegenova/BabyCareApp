import 'package:flutter/material.dart';

import '../../core/constants/app_sizes.dart';
import '../../core/theme/app_colors.dart';
import '../../services/motherhood_data_service.dart';
import '../../widgets/category_item.dart';

class CategoryListScreen extends StatelessWidget {
  const CategoryListScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          tooltip: 'Back',
          onPressed: () => Navigator.pop(context),
          icon: const Icon(
            Icons.chevron_left_rounded,
            color: AppColors.primary,
          ),
        ),
        title: const Text('Sections'),
      ),
      body: GridView.builder(
        padding: const EdgeInsets.all(AppSpacing.xl),
        itemCount: MotherhoodDataService.categories.length,
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          mainAxisSpacing: AppSpacing.lg,
          crossAxisSpacing: AppSpacing.lg,
        ),
        itemBuilder: (context, index) {
          final item = MotherhoodDataService.categories[index];
          return CategoryItem(
            title: item.title,
            image: item.image,
            icon: _iconFor(item.title),
            onTap: () => Navigator.pushNamed(context, item.route),
          );
        },
      ),
    );
  }

  IconData _iconFor(String title) {
    return switch (title) {
      'Pediatricians' => Icons.medical_services_outlined,
      'Daily Care' => Icons.bathtub_outlined,
      'Baby Shop' => Icons.shopping_bag_outlined,
      'Videos' => Icons.play_circle_outline_rounded,
      _ => Icons.child_care_rounded,
    };
  }
}
