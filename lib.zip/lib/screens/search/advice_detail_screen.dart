import 'package:flutter/material.dart';

import '../../core/constants/app_sizes.dart';
import '../../core/theme/app_colors.dart';
import '../../models/advice_model.dart';
import '../../models/service_model.dart';
import '../../services/cart_service.dart';
import '../../widgets/custom_card.dart';

class AdviceDetailScreen extends StatelessWidget {
  const AdviceDetailScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final advice = _adviceFromArgs(context);
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          tooltip: 'Back',
          onPressed: () => Navigator.pop(context),
          icon: const Icon(
            Icons.chevron_left_rounded,
            color: AppColors.primary,
          ),
        ),
        title: Text(advice.category),
      ),
      body: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: AppSizes.screenMaxWidth),
          child: ListView(
            padding: const EdgeInsets.all(AppSpacing.xl),
            children: [
              _HeroImage(advice: advice),
              const SizedBox(height: AppSpacing.xl),
              CustomCard(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      advice.title,
                      style: Theme.of(context).textTheme.headlineSmall
                          ?.copyWith(fontWeight: FontWeight.w700),
                    ),
                    const SizedBox(height: AppSpacing.md),
                    Text(
                      advice.shortDescription,
                      style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        color: AppColors.primary,
                        fontWeight: FontWeight.w600,
                        height: 1.45,
                      ),
                    ),
                    const SizedBox(height: AppSpacing.lg),
                    Text(
                      advice.detailedDescription,
                      style: Theme.of(
                        context,
                      ).textTheme.bodyMedium?.copyWith(height: 1.55),
                    ),
                    const SizedBox(height: AppSpacing.lg),
                    FilledButton.icon(
                      onPressed: () {
                        CartService.add(
                          ServiceModel(
                            title: advice.title,
                            subtitle: advice.category,
                            image: '',
                          ),
                        );
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(
                            content: Text('Tip added to cart'),
                            behavior: SnackBarBehavior.floating,
                          ),
                        );
                      },
                      icon: const Icon(Icons.add_shopping_cart_rounded),
                      label: const Text('Add to cart'),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Advice _adviceFromArgs(BuildContext context) {
    final args = ModalRoute.of(context)?.settings.arguments;
    if (args is Advice) {
      return args;
    }
    return const Advice(
      title: 'Daily Care',
      shortDescription: 'Gentle daily rituals help parents and children.',
      detailedDescription:
          'Open the tips catalog to find guidance on nutrition, sleep, safety, development, and care.',
      category: 'Daily Care',
    );
  }
}

class _HeroImage extends StatelessWidget {
  const _HeroImage({required this.advice});

  final Advice advice;

  @override
  Widget build(BuildContext context) {
    final image = advice.image;
    if (image == null || image.isEmpty) {
      return _FallbackHero(category: advice.category);
    }

    return ClipRRect(
      borderRadius: BorderRadius.circular(AppRadius.lg),
      child: Image.network(
        image,
        height: 260,
        fit: BoxFit.cover,
        errorBuilder: (_, _, _) => _FallbackHero(category: advice.category),
      ),
    );
  }
}

class _FallbackHero extends StatelessWidget {
  const _FallbackHero({required this.category});

  final String category;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 220,
      decoration: BoxDecoration(
        color: AppColors.primarySoft,
        borderRadius: BorderRadius.circular(AppRadius.lg),
      ),
      child: const Icon(
        Icons.child_care_rounded,
        color: AppColors.primary,
        size: 72,
      ),
    );
  }
}
