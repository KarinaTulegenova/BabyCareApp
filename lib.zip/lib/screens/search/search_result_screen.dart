import 'package:flutter/material.dart';

import '../../core/constants/app_routes.dart';
import '../../core/constants/app_sizes.dart';
import '../../core/theme/app_colors.dart';
import '../../models/advice_model.dart';
import '../../services/activity_log_service.dart';
import '../../services/advice_service.dart';
import '../../widgets/custom_card.dart';
import '../../widgets/search_box.dart';

class SearchResultScreen extends StatefulWidget {
  const SearchResultScreen({super.key});

  @override
  State<SearchResultScreen> createState() => _SearchResultScreenState();
}

class _SearchResultScreenState extends State<SearchResultScreen> {
  final AdviceService _service = const AdviceService();
  late Future<List<Advice>> _adviceFuture;
  String _query = '';
  String _category = 'All';
  bool _initialized = false;

  @override
  void initState() {
    super.initState();
    _adviceFuture = _service.search();
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (_initialized) {
      return;
    }
    final args = ModalRoute.of(context)?.settings.arguments;
    _query = args is String ? args : '';
    _adviceFuture = _service.search(query: _query);
    if (_query.isNotEmpty) {
      ActivityLogService.add("Searched advice for '$_query'");
    }
    _initialized = true;
  }

  void _search(String query) {
    final normalizedQuery = query.trim();
    ActivityLogService.add(
      normalizedQuery.isEmpty
          ? 'Opened advice catalog'
          : "Searched advice for '$normalizedQuery'",
    );
    setState(() {
      _query = normalizedQuery;
      _adviceFuture = _service.search(
        query: _query,
        category: _category == 'All' ? null : _category,
      );
    });
  }

  void _filter(String category) {
    setState(() {
      _category = category;
      _adviceFuture = _service.search(
        query: _query,
        category: category == 'All' ? null : category,
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          tooltip: 'Back',
          onPressed: () => Navigator.pop(context),
          icon: const Icon(
            Icons.chevron_left_rounded,
            color: AppColors.primary,
          ),
        ),
        title: const Text('Parenting Tips'),
      ),
      body: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: AppSizes.screenMaxWidth),
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(
                  AppSpacing.xl,
                  AppSpacing.lg,
                  AppSpacing.xl,
                  AppSpacing.sm,
                ),
                child: SearchBox(
                  hint: 'Search care, sleep, or nutrition',
                  initialValue: _query,
                  onSearch: _search,
                ),
              ),
              FutureBuilder<List<String>>(
                future: _service.categories(),
                builder: (context, snapshot) {
                  final categories = ['All', ...snapshot.data ?? const []];
                  return SizedBox(
                    height: 46,
                    child: ListView.separated(
                      padding: const EdgeInsets.symmetric(
                        horizontal: AppSpacing.xl,
                      ),
                      scrollDirection: Axis.horizontal,
                      itemCount: categories.length,
                      separatorBuilder: (_, _) =>
                          const SizedBox(width: AppSpacing.sm),
                      itemBuilder: (context, index) {
                        final category = categories[index];
                        final selected = category == _category;
                        return ChoiceChip(
                          label: Text(category),
                          selected: selected,
                          onSelected: (_) => _filter(category),
                          selectedColor: AppColors.primarySoft,
                          side: BorderSide(
                            color: selected
                                ? AppColors.primary
                                : AppColors.mutedLight,
                          ),
                        );
                      },
                    ),
                  );
                },
              ),
              Expanded(
                child: FutureBuilder<List<Advice>>(
                  future: _adviceFuture,
                  builder: (context, snapshot) {
                    if (snapshot.connectionState == ConnectionState.waiting) {
                      return const Center(
                        child: CircularProgressIndicator(
                          color: AppColors.primary,
                        ),
                      );
                    }

                    if (snapshot.hasError) {
                      return const _SearchStateMessage(
                        icon: Icons.error_outline_rounded,
                        title: 'Catalog unavailable',
                        message: 'Could not open the local advice catalog.',
                      );
                    }

                    final advice = snapshot.data ?? const <Advice>[];
                    if (advice.isEmpty) {
                      return const _SearchStateMessage(
                        icon: Icons.search_off_rounded,
                        title: 'No results found',
                        message: 'Try another query or category.',
                      );
                    }

                    return ListView.builder(
                      padding: const EdgeInsets.all(AppSpacing.xl),
                      itemCount: advice.length,
                      itemBuilder: (context, index) {
                        final item = advice[index];
                        return Padding(
                          padding: const EdgeInsets.only(bottom: AppSpacing.lg),
                          child: CustomCard(
                            onTap: () {
                              ActivityLogService.add(
                                'Opened advice ${item.title}',
                              );
                              Navigator.pushNamed(
                                context,
                                AppRoutes.adviceDetail,
                                arguments: item,
                              );
                            },
                            child: Row(
                              children: [
                                _AdviceThumb(advice: item),
                                const SizedBox(width: AppSpacing.lg),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        item.title,
                                        maxLines: 2,
                                        overflow: TextOverflow.ellipsis,
                                        style: Theme.of(context)
                                            .textTheme
                                            .titleMedium
                                            ?.copyWith(
                                              fontWeight: FontWeight.w700,
                                            ),
                                      ),
                                      const SizedBox(height: AppSpacing.xs),
                                      Text(
                                        item.shortDescription,
                                        maxLines: 2,
                                        overflow: TextOverflow.ellipsis,
                                        style: Theme.of(context)
                                            .textTheme
                                            .bodySmall
                                            ?.copyWith(color: AppColors.muted),
                                      ),
                                      const SizedBox(height: AppSpacing.sm),
                                      Text(
                                        item.category,
                                        style: Theme.of(context)
                                            .textTheme
                                            .labelMedium
                                            ?.copyWith(
                                              color: AppColors.primary,
                                              fontWeight: FontWeight.w700,
                                            ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        );
                      },
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _AdviceThumb extends StatelessWidget {
  const _AdviceThumb({required this.advice});

  final Advice advice;

  @override
  Widget build(BuildContext context) {
    final image = advice.image;
    if (image == null || image.isEmpty) {
      return _IconThumb(category: advice.category);
    }

    return ClipRRect(
      borderRadius: BorderRadius.circular(AppRadius.lg),
      child: Image.network(
        image,
        width: 92,
        height: 92,
        fit: BoxFit.cover,
        errorBuilder: (_, _, _) => _IconThumb(category: advice.category),
      ),
    );
  }
}

class _IconThumb extends StatelessWidget {
  const _IconThumb({required this.category});

  final String category;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 92,
      height: 92,
      decoration: BoxDecoration(
        color: AppColors.primarySoft,
        borderRadius: BorderRadius.circular(AppRadius.lg),
      ),
      child: Icon(_iconFor(category), color: AppColors.primary, size: 34),
    );
  }

  IconData _iconFor(String category) {
    return switch (category) {
      'Baby Nutrition' => Icons.restaurant_rounded,
      'Sleep' => Icons.nightlight_round,
      'Child Safety' => Icons.health_and_safety_rounded,
      'Emotional Development' => Icons.favorite_border_rounded,
      'Screen Time Limits' => Icons.devices_other_rounded,
      'Pediatrician Tips' => Icons.medical_services_rounded,
      'Daily Care' => Icons.bathtub_rounded,
      'Child Development' => Icons.toys_rounded,
      _ => Icons.child_care_rounded,
    };
  }
}

class _SearchStateMessage extends StatelessWidget {
  const _SearchStateMessage({
    required this.icon,
    required this.title,
    required this.message,
  });

  final IconData icon;
  final String title;
  final String message;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(AppSpacing.xl),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, size: 48, color: AppColors.primary),
            const SizedBox(height: AppSpacing.md),
            Text(
              title,
              textAlign: TextAlign.center,
              style: Theme.of(
                context,
              ).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w700),
            ),
            const SizedBox(height: AppSpacing.sm),
            Text(
              message,
              textAlign: TextAlign.center,
              style: Theme.of(
                context,
              ).textTheme.bodyMedium?.copyWith(color: AppColors.muted),
            ),
          ],
        ),
      ),
    );
  }
}
