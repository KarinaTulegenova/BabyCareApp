class Advice {
  const Advice({
    required this.title,
    required this.shortDescription,
    required this.detailedDescription,
    required this.category,
    this.image,
  });

  final String title;
  final String shortDescription;
  final String detailedDescription;
  final String category;
  final String? image;

  factory Advice.fromJson(Map<String, dynamic> json) {
    return Advice(
      title: (json['title'] as String?) ?? '',
      shortDescription: (json['shortDescription'] as String?) ?? '',
      detailedDescription: (json['detailedDescription'] as String?) ?? '',
      category: (json['category'] as String?) ?? '',
      image: json['image'] as String?,
    );
  }

  bool matches(String query) {
    final normalized = query.trim().toLowerCase();
    if (normalized.isEmpty) {
      return true;
    }

    return title.toLowerCase().contains(normalized) ||
        shortDescription.toLowerCase().contains(normalized) ||
        detailedDescription.toLowerCase().contains(normalized) ||
        category.toLowerCase().contains(normalized);
  }
}
