class TrainingCourse {
  const TrainingCourse({
    required this.title,
    required this.expertName,
    required this.youtubeUrl,
    required this.thumbnailUrl,
  });

  final String title;
  final String expertName;
  final String youtubeUrl;
  final String thumbnailUrl;
}
