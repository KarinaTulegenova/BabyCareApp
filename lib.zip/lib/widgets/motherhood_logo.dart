import 'package:flutter/material.dart';

import '../core/constants/app_assets.dart';

class MotherhoodLogo extends StatelessWidget {
  const MotherhoodLogo({super.key, this.size = 184});

  final double size;

  @override
  Widget build(BuildContext context) {
    return Image.asset(
      AppAssets.appLogo,
      width: size,
      height: size,
      fit: BoxFit.contain,
      cacheWidth: (size * MediaQuery.devicePixelRatioOf(context)).round(),
    );
  }
}
