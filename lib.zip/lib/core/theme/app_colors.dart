import 'package:flutter/material.dart';

class AppColors {
  const AppColors._();

  static const Color primary = Color(0xFFC4ACE8);
  static const Color primaryLight = Color(0xFFDED5EE);
  static const Color primarySoft = Color(0xFFF3ECFA);
  static const Color background = Color(0xFFFFF7F8);
  static const Color surface = Color(0xFFFFFFFF);
  static const Color text = Color(0xFF49334E);
  static const Color muted = Color(0xFF81717F);
  static const Color mutedLight = Color(0xFFF2DFE1);
  static const Color success = Color(0xFFF6BFC8);
  static const Color warning = Color(0xFFD9A6CA);
  static const Color shadow = Color(0x14162233);
}
