class AppConstants {
  const AppConstants._();

  static const String appName = 'Baby Care';
  static const String tagline = 'Gentle support for parents every day';
  static const String packageName = 'com.example.petguardian';

  // Store-facing version name for release 1.0.0+1.
  static const String versionName = '1.0.0';

  // Integer build number used as Android versionCode and iOS CFBundleVersion.
  static const int buildNumber = 1;
  static const String city = 'Astana, Kazakhstan';
}
