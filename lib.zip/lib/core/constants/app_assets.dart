class AppAssets {
  const AppAssets._();

  static const String icon = 'assets/logo.png';
  static const String splashLogo = 'assets/logo.png';
  static const String appLogo = 'assets/logo.png';

  static const String doctorAigerim = 'assets/Aigerim.png';
  static const String doctorAruzhan = 'assets/Aruzhan.png';
  static const String doctorAlikhan = 'assets/Alikhan.png';

  static const String categoryNutrition = 'assets/nutrition.png';
  static const String categoryHealth = 'assets/health.png';
  static const String categoryToys = 'assets/toys.png';
  static const String categoryHygiene = 'assets/hygiene.png';
  static const String categoryAccessories = 'assets/accesories.png';
  static const String categoryClothes = 'assets/clothes.png';

  static const String dailySupport = 'assets/daily_support_for_parents.png';
  static const String newbornCareBasics = 'assets/newborn_care_basics.png';
  static const String checkHomeSafely = 'assets/check_home_safely.png';
  static const String telegram = 'assets/telegram.png';

  static const String vetDoctor = doctorAigerim;
  static const String grooming = categoryHygiene;
  static const String shopPets = categoryNutrition;
  static const String trainingDog = newbornCareBasics;
  static const String event = dailySupport;
  static const String community = telegram;
  static const String doctorAnna = doctorAigerim;
  static const String doctorVernon = doctorAlikhan;
  static const String doctorMaria = doctorAruzhan;
  static const String bath = categoryHygiene;
  static const String hair = categoryHygiene;
  static const String nail = categoryHygiene;
  static const String ear = categoryHealth;
  static const String food = categoryNutrition;
  static const String healthy = categoryHealth;
  static const String toys = categoryToys;
  static const String accessories = categoryAccessories;
  static const String clothes = categoryClothes;
  static const String course1 = newbornCareBasics;
  static const String course2 = dailySupport;
  static const String course3 = categoryNutrition;
  static const String course4 = categoryToys;
}
